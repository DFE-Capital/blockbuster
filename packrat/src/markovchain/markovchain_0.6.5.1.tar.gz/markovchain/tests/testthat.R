library(testthat)
library(markovchain)
test_check("markovchain")
