library(testthat)
library(govstyle)
library(ggplot2)
library(png)
library(visualTest)
# Install visualTest to allow checking against a reference plot.
#devtools::install_github("MangoTheCat/visualTest")

test_check("govstyle")
